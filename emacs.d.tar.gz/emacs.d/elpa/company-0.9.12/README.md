See the [homepage](http://company-mode.github.com/).

[![Build Status](https://travis-ci.org/company-mode/company-mode.png?branch=master)](https://travis-ci.org/company-mode/company-mode)
[![Melpa Status](http://melpa.milkbox.net/packages/company-badge.svg)](http://melpa.milkbox.net/#/company)
